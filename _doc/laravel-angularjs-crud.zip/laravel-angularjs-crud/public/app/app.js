var app = angular.module('employeeRecords', [])
        .constant('API_URL', 'http://localhost/angulara/public/api/v1/');